package mx.unam.ciencias.modelado.practica4.empresa;

/**Enumeración para las areas de trabajo de los empleados. */
public enum AreaDeTrabajo{
    ATENCION_A_CLIENTES,
    RECURSOS_HUMANOS,
    CONTABILIDAD,
    DESARROLLO,
    MERCADOTECNIA,
    DIRECCION;
}